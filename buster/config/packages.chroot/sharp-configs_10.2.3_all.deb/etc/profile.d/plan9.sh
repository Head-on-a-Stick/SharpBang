export PLAN9=/usr/lib/plan9
export PATH="${PATH}:${PLAN9}/bin"
export MANPATH="${MANPATH}:${PLAN9}/man"

